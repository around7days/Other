/**
 * メニュー画面JS
 */
$(function() {

	/** form */
	var fmMain = $("#formMain");

	/** デフォルトURL */
	var defaultUrl = fmMain.attr("action");

	/**
	 * メニュークリック
	 */
	$("#menuList button[type='submit']").on("click", function() {
		var url = defaultUrl;
		fmMain.attr("action", url);

		return true;
	});

	/**
	 * サブメニューボタン押下
	 */
	 $("#trtg111").on("click", function() {
		var id = $(this).attr("id");
		var url = "../../templates/html/" + id + ".html";
		fmMain.attr("action", url);
		return true;
	});

	/**
	 * サブメニューボタン押下
	 */
	 $("#trtg121").on("click", function() {
		var id = $(this).attr("id");
		var url = "../../templates/html/" + id + ".html";
		fmMain.attr("action", url);
		return true;
	});

	/**
	 * サブメニューボタン押下
	 */
	 $("#trtg211").on("click", function() {
		var id = $(this).attr("id");
		var url = "../../templates/html/" + id + ".html";
		fmMain.attr("action", url);
		return true;
	});

	/**
	 * サブメニューボタン押下
	 */
	 $("#trtg221").on("click", function() {
		var id = $(this).attr("id");
		var url = "../../templates/html/" + id + ".html";
		fmMain.attr("action", url);
		return true;
	});

	/**
	 * サブメニューボタン押下
	 */
	 $("#trtg222").on("click", function() {
		var id = $(this).attr("id");
		var url = "../../templates/html/" + id + ".html";
		fmMain.attr("action", url);
		return true;
	});

	/**
	 * サブメニューボタン押下
	 */
	 $("#trtg231").on("click", function() {
		var id = $(this).attr("id");
		var url = "../../templates/html/" + id + ".html";
		fmMain.attr("action", url);
		return true;
	});

	/**
	 * サブメニューボタン押下
	 */
	 $("#trtg311").on("click", function() {
		var id = $(this).attr("id");
		var url = "../../templates/html/" + id + ".html";
		fmMain.attr("action", url);
		return true;
	});

	/**
	 * サブメニューボタン押下
	 */
	 $("#trtg321").on("click", function() {
		var id = $(this).attr("id");
		var url = "../../templates/html/" + id + ".html";
		fmMain.attr("action", url);
		return true;
	});

	/**
	 * サブメニューボタン押下
	 */
	 $("#trtg411").on("click", function() {
		var id = $(this).attr("id");
		var url = "../../templates/html/" + id + ".html";
		fmMain.attr("action", url);
		return true;
	});

	/**
	 * サブメニューボタン押下
	 */
	 $("#trtg511").on("click", function() {
		var id = $(this).attr("id");
		var url = "../../templates/html/" + id + ".html";
		fmMain.attr("action", url);
		return true;
	});

	/**
	 * サブメニューボタン押下
	 */
	 $("#trtg521").on("click", function() {
		var id = $(this).attr("id");
		var url = "../../templates/html/" + id + ".html";
		fmMain.attr("action", url);
		return true;
	});

	/**
	 * サブメニューボタン押下
	 */
	 $("#trtg531").on("click", function() {
		var id = $(this).attr("id");
		var url = "../../templates/html/" + id + ".html";
		fmMain.attr("action", url);
		return true;
	});

	/**
	 * サブメニューボタン押下
	 */
	 $("#trtg541").on("click", function() {
		var id = $(this).attr("id");
		var url = "../../templates/html/" + id + ".html";
		fmMain.attr("action", url);
		return true;
	});

});
