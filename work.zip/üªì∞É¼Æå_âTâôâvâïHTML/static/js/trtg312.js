/**
 * 取次納品処理画面JS
 */
$(function() {

	/** form */
	var fmMain = $("#formMain");

	/** デフォルトURL */
	var defaultUrl = fmMain.attr("action");

	/**
	 * 検索ボタン押下
	 */
	$("#search").on("click", function() {
		if (!window.confirm("検索ボタン")) {
			return false;
		}
		var url = defaultUrl + "?search";
		fmMain.attr("action", url);
		return true;
	});

	/**
	 * クリアボタン押下
	 */
	$("#clear").on("click", function() {
		if (!window.confirm("クリアボタン")) {
			return false;
		}
		var url = defaultUrl + "?clear";
		fmMain.attr("action", url);
		return true;
	});

	/**
	 * ファイル再チェックボタン押下
	 */
	$("#fileReChk").on("click", function() {
		if (!window.confirm("ファイル再チェックボタン")) {
			return false;
		}
		var url = defaultUrl + "?fileReChk";
		fmMain.attr("action", url);
		return true;
	});

	/**
	 * 納品対象出力ボタン押下
	 */
	$("#nouhinOutput").on("click", function() {
		if (!window.confirm("納品対象出力ボタン")) {
			return false;
		}
		var url = defaultUrl + "?nouhinOutput";
		fmMain.attr("action", url);
		return true;
	});

	/**
	 * 対象納品日反映ボタン押下
	 */
	$("#updNouhinDate").on("click", function() {
		if (!window.confirm("対象納品日反映ボタン")) {
			return false;
		}
		var url = defaultUrl + "?updNouhinDate";
		fmMain.attr("action", url);
		return true;
	});

	/**
	 * 戻るボタン押下
	 */
	$("#back").on("click", function() {
		var url = defaultUrl + "trtg311.html";
		fmMain.attr("action", url);
		return true;
	});

	/**
	 * 対象複写ボタン押下
	 */
	$("#edit").on("click", function() {
		var url = defaultUrl + "trtg313.html";
		fmMain.attr("action", url);
		return true;
	});

});