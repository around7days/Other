/**
 * RMS固有クラス
 */
var Rms = function() {

};

/**
 * 関数定義
 */
Rms.prototype = {

};

/*
 * グローバル変数
 */
// RMS共通関数
var rms = new Rms();
