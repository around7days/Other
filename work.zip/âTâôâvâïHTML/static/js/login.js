/**
 * ログイン画面JS
 */
$(function() {

	/** form */
	var fmMain = $("#formMain");

	/**
	 * 初期処理
	 */
	{
		// TODO 開発中のお手軽ログイン用設定
		// ローカルストレージから値の取得
		var userId = localStorage.getItem("userId");
		var password = localStorage.getItem("password");
		// 値の反映
		if (userId != null) {
			$("#userId").val(userId);
		}
		if (password != null) {
			$("#password").val(password);
		}
	}

	/**
	 * ログインボタン押下（遷移用）
	 */
	$("#next").on("click", function() {
		var url = "../../templates/html/menu.html";
		fmMain.attr("action", url);
		return true;
	});

	/**
	 * Enterキーでログインボタン押下<br>
	 * ※control.jsの処理を上書き
	 */
	$("input").keydown(function(e) {
		if ((e.which && e.which === 13) || (e.keyCode && e.keyCode === 13)) {
			$("#login").click();
		}
	});
});
