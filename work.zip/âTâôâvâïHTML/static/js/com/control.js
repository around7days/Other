$(function() {

	/**
	 * 多重submit防止<br>
	 * （一定秒画面をロック）
	 */
	$("form").on("submit", function() {
		$.blockUI({
			overlayCSS : {
				backgroundColor : "#ffffff",
				opacity : 0.0
			},
			message : null
		});

		setTimeout($.unblockUI, 3000);
	});

	/**
	 * inputタグ内のEnterキー無効
	 */
	$("input").keydown(function(e) {
		if ((e.which && e.which === 13) || (e.keyCode && e.keyCode === 13)) {
			return false;
		} else {
			return true;
		}
	});

	/**
	 * 年月カレンダー表示
	 */
	$(".datepicker-ymd").focus(function() {
		$(this).blur();
	});
	$(".datepicker-ymd").keydown(function() {
		return false;
	});
	$(".datepicker-ymd").attr({
		placeholder : "yyyy/mm/dd"
	});
	$(".datepicker-ymd").datepicker({
		format : "yyyy/mm/dd",
		minViewMode : "days",
		maxViewMode : "years",
		orientation : "bottom auto",
		clearBtn : true,
		autoclose : true,
		daysOfWeekHighlighted: [0, 6],
		todayHighlight: true,
		weekStart : 1,
		language : "ja"
	});

	/**
	 * DataTables設定
	 */
	$(".dataTable").dataTable({
		paging : true,
		pageLength : 5,
		lengthChange : false,
		info : true,
		searching : false,
		ordering : false
	});

	/**
	 * DataTables設定（ページング機能OFF）
	 */
	$(".dataTable2").dataTable({
		paging : false,
		searching : false,
		info : false,
		ordering : false
	});

	/**
	 * DataTables設定（横スクロール設定付き）
	 */
	$(".dataTable3").dataTable({
		paging : true,
		pageLength : 5,
		lengthChange : false,
		info : true,
		scrollX : "1000vw",
		searching : false,
		ordering : false,
		order : []
	});

	/**
	 * DataTables設定（111:取次納品検索画面専用）
	 */
	$(".dataTable-111").dataTable({
		paging : true,
		pageLength : 5,
		lengthChange : false,
		scrollX : true,
		searching : false,
		ordering : false,
		info : true,
		columnDefs: [
				 { targets: 0,  width: 40 }
				,{ targets: 1,  width: 50 }
				,{ targets: 2,  width: 65 }
				,{ targets: 3,  width: 65 }
				,{ targets: 4,  width: 50 }
				,{ targets: 5,  width: 80 }
				,{ targets: 6,  width: 120 }
				,{ targets: 7,  width: 100 }
				,{ targets: 8,  width: 300 }
				,{ targets: 9,  width: 40 }
				,{ targets: 10, width: 130 }
				,{ targets: 11, width: 130 }
				,{ targets: 12, width: 130 }
				,{ targets: 13, width: 130 }
				,{ targets: 14, width: 130 }
				,{ targets: 15, width: 50 }
				,{ targets: 16, width: 50 }
				,{ targets: 17, width: 50 }
				,{ targets: 18, width: 50 }
				,{ targets: 19, width: 200 }
				,{ targets: 20, width: 130 }
				,{ targets: 21, width: 100 }
			],
		order : []
	});

	/**
	 * DataTables設定（112:取次納品詳細画面専用）
	 */
	$(".dataTable-112").dataTable({
		lengthChange : false,
		paging : false,
		searching : true,
		ordering : false,
		info : false,
		order : []
	});

	/**
	 * 上に戻るアンカー操作（スクロールイベント）
	 */
	$(window).on("scroll", function() {
		if ($(this).scrollTop() > 100) {
			$("#pageTop").fadeIn("slow");
		} else {
			$("#pageTop").fadeOut("slow");
		}
	});

	/**
	 * 上に戻るアンカー押下時
	 */
	$("#pageTop").on("click", function() {
		// スクロールの速度（ミリ秒）
		var speed = 400;
		// 移動先を数値で取得
		var position = $("html").offset().top;
		// スムーススクロール
		$("body,html").animate({
			scrollTop : position
		}, speed, "swing");
		return false;
	});

});
