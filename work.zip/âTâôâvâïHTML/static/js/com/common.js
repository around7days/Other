/**
 * プロジェクト固有クラス
 */
var Ams = function() {

};

/**
 * 関数定義
 */
Ams.prototype = {

};

/*
 * グローバル変数
 */
var ams = new Ams();
