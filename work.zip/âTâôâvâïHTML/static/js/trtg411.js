/**
 * 取次納品実績出力画面JS
 */
$(function() {

	/** form */
	var fmMain = $("#formMain");

	/** デフォルトURL */
	var defaultUrl = fmMain.attr("action") + "mst/trtg411";

	/**
	 * 実行ボタン押下
	 */
	$("#output").on("click", function() {
		if (!window.confirm("出力しますか？")) {
			return false;
		}
		var url = defaultUrl + "?output";
		fmMain.attr("action", url);
		return true;
	});

	/**
	 * 戻るボタン押下
	 */
	$("#back").on("click", function() {
		var url = defaultUrl + "?back";
		fmMain.attr("action", url);
		return true;
	});

});