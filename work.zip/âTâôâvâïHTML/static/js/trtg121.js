/**
 * バッチ処理手動実行JS
 */
$(function() {

	/** form */
	var fmMain = $("#formMain");

	/** デフォルトURL */
	var defaultUrl = fmMain.attr("action") + "mst/trtg121";

	/**
	 * 実行ボタン押下
	 */
	$("#execute").on("click", function() {
		if (!window.confirm("実行しますか？")) {
			return false;
		}
		var url = defaultUrl + "?execute";
		fmMain.attr("action", url);
		return true;
	});

	 
	/**
	 * 戻るボタン押下
	 */
	$("#back").on("click", function() {
		var url = defaultUrl + "?back";
		fmMain.attr("action", url);
		return true;
	});

});